#include "Engine.h"


int main()
{
    // Create an instance of the Engine class
    Engine engine;
    // Run the game engine
    engine.run();
    // Return 0 to indicate successful program execution
    return 0;
}